var indexSectionsWithContent =
{
  0: "_abcdefhklmnoprstuv",
  1: "m",
  2: "adms",
  3: "adefklmopsu",
  4: "abcdefhklmnprstv",
  5: "m",
  6: "_d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros"
};

