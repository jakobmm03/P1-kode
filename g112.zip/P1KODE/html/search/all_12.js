var searchData=
[
  ['vccpin_0',['vccPin',['../SenderEspKodeP1_8ino.html#a495cc3c508cf0d2d5a917b295be6ffcb',1,'SenderEspKodeP1.ino']]]
];
