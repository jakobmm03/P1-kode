var searchData=
[
  ['failsafe_0',['failsafe',['../SenderEspKodeP1_8ino.html#ab708b23c71c9a17d6c65cdcd4687d56e',1,'SenderEspKodeP1.ino']]],
  ['failsafeavg_1',['failsafeAvg',['../structMessegeData.html#a9bfaeb65695cdc6f0e27aaf800904f58',1,'MessegeData']]]
];
