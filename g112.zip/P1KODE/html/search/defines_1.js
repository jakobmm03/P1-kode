var searchData=
[
  ['dhtpin_0',['DHTPIN',['../SenderEspKodeP1_8ino.html#a757bb4e2bff6148de6ef3989b32a0126',1,'SenderEspKodeP1.ino']]],
  ['dhttype_1',['DHTTYPE',['../SenderEspKodeP1_8ino.html#a2c509dba12bba99883a5be9341b7a0c5',1,'SenderEspKodeP1.ino']]]
];
