var searchData=
[
  ['echopin_0',['echoPin',['../SenderEspKodeP1_8ino.html#afdad0216184afab1698374208a9a260d',1,'SenderEspKodeP1.ino']]],
  ['espnow_1',['ESPNOW',['../SenderEspKodeP1_8ino.html#aecb87b3fb197df54fe52a30efac78132',1,'SenderEspKodeP1.ino']]]
];
