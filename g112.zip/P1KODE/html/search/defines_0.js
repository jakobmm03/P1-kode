var searchData=
[
  ['_5f_5fmyvrs_5f_5f_0',['__MYVRS__',['../SenderEspKodeP1_8ino.html#aff47b320cfe8423c4b1b018d2ad96bde',1,'SenderEspKodeP1.ino']]]
];
