var searchData=
[
  ['messegedata_0',['MessegeData',['../structMessegeData.html',1,'']]]
];
