var searchData=
[
  ['temperature_0',['temperature',['../structMessegeData.html#a30a033fed420095bdaad375aabfde837',1,'MessegeData']]],
  ['tft_1',['tft',['../ModtagDataVisDisplay2_8ino.html#ac5d2dc3534f30f704fd7529ad0f89ff1',1,'ModtagDataVisDisplay2.ino']]],
  ['timer_2',['timer',['../ModtagDataVisDisplay2_8ino.html#a61d9ef65d75b66821896182b133b31de',1,'ModtagDataVisDisplay2.ino']]],
  ['timestamp_3',['timestamp',['../ModtagDataVisDisplay2_8ino.html#acba7776dcc1861edfe0e9c5736de4df8',1,'timestamp:&#160;ModtagDataVisDisplay2.ino'],['../SenderEspKodeP1_8ino.html#acba7776dcc1861edfe0e9c5736de4df8',1,'timestamp:&#160;SenderEspKodeP1.ino']]],
  ['timetoread_5fdhl_4',['timeToRead_DHL',['../SenderEspKodeP1_8ino.html#aeffa50df18fe8315815f9156300ea263',1,'SenderEspKodeP1.ino']]],
  ['timetoread_5ffailsafe_5',['timeToRead_failsafe',['../SenderEspKodeP1_8ino.html#acd223e38d98f1e789c8be73aabbaaa50',1,'SenderEspKodeP1.ino']]],
  ['timetoread_5fultralyd_6',['timeToRead_ultralyd',['../SenderEspKodeP1_8ino.html#ac61c3cef2cfa5d68ef1ca3a77ed60eda',1,'SenderEspKodeP1.ino']]],
  ['tmp_7',['tmp',['../SenderEspKodeP1_8ino.html#a869dc96b4fa3d9bd19c20088b1fc9cf4',1,'SenderEspKodeP1.ino']]],
  ['transmissiontime_8',['transmissionTime',['../ModtagDataVisDisplay2_8ino.html#a5e3cd2626e9878d64c0e086fdafb211c',1,'ModtagDataVisDisplay2.ino']]],
  ['trigpin_9',['trigPin',['../SenderEspKodeP1_8ino.html#a6ff4f36212df4d5fa0cd6ef1247d280a',1,'SenderEspKodeP1.ino']]]
];
