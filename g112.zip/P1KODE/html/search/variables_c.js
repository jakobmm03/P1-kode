var searchData=
[
  ['reading_0',['reading',['../SenderEspKodeP1_8ino.html#a5fa8d7fdcda2ed9555ad800a40a1a810',1,'SenderEspKodeP1.ino']]],
  ['readingsum_1',['readingSum',['../SenderEspKodeP1_8ino.html#af22a4b6b1e2890b7a446eeea936f6bba',1,'SenderEspKodeP1.ino']]],
  ['readpin_2',['readPin',['../SenderEspKodeP1_8ino.html#a10fee2b714896541ea66d87c262bcbd9',1,'SenderEspKodeP1.ino']]],
  ['readsprloop_3',['readsPrLoop',['../SenderEspKodeP1_8ino.html#ac9fa22ef02eb8bc43350dd71130116cf',1,'SenderEspKodeP1.ino']]],
  ['recievetime_4',['recieveTime',['../ModtagDataVisDisplay2_8ino.html#a5f8946b430578d7649e6661c535c1fcf',1,'ModtagDataVisDisplay2.ino']]],
  ['recivet_5',['recivet',['../ModtagDataVisDisplay2_8ino.html#a14bbdecdcaeeea41af36cc8f3f04decc',1,'recivet:&#160;ModtagDataVisDisplay2.ino'],['../SenderEspKodeP1_8ino.html#a14bbdecdcaeeea41af36cc8f3f04decc',1,'recivet:&#160;SenderEspKodeP1.ino']]],
  ['relay_6',['relay',['../SenderEspKodeP1_8ino.html#aa1e1c260442e47f064307501b3614a80',1,'SenderEspKodeP1.ino']]],
  ['relaypin_7',['relayPin',['../SenderEspKodeP1_8ino.html#a5bc430e8bb7c2d7be2f5c40877098c5a',1,'SenderEspKodeP1.ino']]]
];
