var searchData=
[
  ['messegedata_0',['MessegeData',['../ModtagDataVisDisplay2_8ino.html#a8ea0bd12620495561588a8402860833a',1,'MessegeData:&#160;ModtagDataVisDisplay2.ino'],['../SenderEspKodeP1_8ino.html#a8ea0bd12620495561588a8402860833a',1,'MessegeData:&#160;SenderEspKodeP1.ino']]]
];
