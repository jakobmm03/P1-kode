var searchData=
[
  ['safstand_0',['Safstand',['../structMessegeData.html#a34ed16cda024dc729a100d703a64cdda',1,'MessegeData']]],
  ['safstand_1',['sAfstand',['../structMessegeData.html#afb17f795e6f86046ed12146790f5eb98',1,'MessegeData']]],
  ['sendstart_2',['sendStart',['../structMessegeData.html#aaea3ec9cc9bc734609348073069ef16e',1,'MessegeData']]],
  ['sensorstate_3',['sensorState',['../SenderEspKodeP1_8ino.html#adc80a380b0b33e23537e4169d66b5080',1,'SenderEspKodeP1.ino']]],
  ['sound_4',['sound',['../SenderEspKodeP1_8ino.html#ae684987a8c0b21f4d6dea432e56b58ff',1,'SenderEspKodeP1.ino']]],
  ['state_5',['state',['../SenderEspKodeP1_8ino.html#a89f234133d3efe315836311cbf21c64b',1,'SenderEspKodeP1.ino']]]
];
