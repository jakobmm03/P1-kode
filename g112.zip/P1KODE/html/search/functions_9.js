var searchData=
[
  ['sensorstyring_0',['sensorstyring',['../SenderEspKodeP1_8ino.html#a66694ab1810bfeea2e31ccc68a5cbaa4',1,'SenderEspKodeP1.ino']]],
  ['setup_1',['setup',['../ModtagDataVisDisplay2_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;ModtagDataVisDisplay2.ino'],['../SenderEspKodeP1_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;SenderEspKodeP1.ino']]],
  ['start_2',['Start',['../SenderEspKodeP1_8ino.html#a07aaf1227e4d645f15e0a964f54ef291',1,'SenderEspKodeP1.ino']]],
  ['startultralyd_3',['Startultralyd',['../SenderEspKodeP1_8ino.html#a07817a4d8a23ac89747c6316830f3392',1,'SenderEspKodeP1.ino']]]
];
