var searchData=
[
  ['failsafe_0',['failsafe',['../SenderEspKodeP1_8ino.html#ab708b23c71c9a17d6c65cdcd4687d56e',1,'SenderEspKodeP1.ino']]]
];
