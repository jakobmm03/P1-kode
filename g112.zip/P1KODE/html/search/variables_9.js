var searchData=
[
  ['maxafstand_0',['maxafstand',['../SenderEspKodeP1_8ino.html#ab22279968a82b2667ff9531ee13ef3b0',1,'SenderEspKodeP1.ino']]],
  ['maxlimit_1',['maxLimit',['../SenderEspKodeP1_8ino.html#a0cc17b06c98d219cfd65aac8bfdc1fbc',1,'SenderEspKodeP1.ino']]],
  ['mydata_2',['myData',['../ModtagDataVisDisplay2_8ino.html#a5fbe2af97e3251b0d399cab3a0495d93',1,'myData:&#160;ModtagDataVisDisplay2.ino'],['../SenderEspKodeP1_8ino.html#a5fbe2af97e3251b0d399cab3a0495d93',1,'myData:&#160;SenderEspKodeP1.ino']]]
];
