var searchData=
[
  ['knap_0',['knap',['../SenderEspKodeP1_8ino.html#a45b12b19f3ce240df0a1c8891fae9a85',1,'SenderEspKodeP1.ino']]],
  ['knaptid_1',['knaptid',['../SenderEspKodeP1_8ino.html#a84c7240288fc9d0a5e0725e340dbde71',1,'SenderEspKodeP1.ino']]],
  ['knaptrykalarm_2',['knaptrykalarm',['../SenderEspKodeP1_8ino.html#a2991cda48f280c298f27aa9962a779ad',1,'SenderEspKodeP1.ino']]]
];
