var searchData=
[
  ['ondatarecv_0',['OnDataRecv',['../ModtagDataVisDisplay2_8ino.html#ad6e972502e97eda80da46e228a521d30',1,'ModtagDataVisDisplay2.ino']]],
  ['ondatasent_1',['OnDataSent',['../SenderEspKodeP1_8ino.html#a1ec6b84c5d1247e1390758d6df12d0dc',1,'SenderEspKodeP1.ino']]]
];
