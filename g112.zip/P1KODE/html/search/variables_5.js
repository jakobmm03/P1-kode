var searchData=
[
  ['failsafeavg_0',['failsafeAvg',['../structMessegeData.html#a9bfaeb65695cdc6f0e27aaf800904f58',1,'MessegeData']]]
];
